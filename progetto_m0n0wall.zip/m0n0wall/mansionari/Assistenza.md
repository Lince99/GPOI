
## Posizione: Addetto all'assistenza clienti

## Dipartimento: Assistenza clienti

## Dipendenza gerarchica: Direttore, Amministratore generale

### Dipendenza funzionale:

## A lui riportano:

## Rapporti interni: tutti

## Rapporti esterni: clienti

## Scopo della Posizione: assicurare il corretto funzionamento dei servizi ai clienti

## Responsabilita':
-Riferire ai programmatori gli eventuali bug del software
-Assicurare al cliente il dovuto supporto

## Compiti e mansioni:
-Rispondere prontamente alle domande del cliente
-Informare i programmatori di eventuali problemi o migliorie
