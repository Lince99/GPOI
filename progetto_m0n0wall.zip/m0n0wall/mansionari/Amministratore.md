
## Posizione: Amministratore Generale

## Dipartimento: Amministrazione

## Dipendenza gerarchica: Direttore

### Dipendena funzionale: Amministrazione generale, controllo sottoposti

### A lui riportano: programmatori software sicurezza, programmatori software m0n0wall, addetti all'assistenza

## Rapporti interfuzionali interni: tutti i dipartimenti

## Rapporti esterni:  aziende "Netgear", "Sandisk" (fornitori), banca, servizi logistici (Magazzino, logistica), enti pubblici

## Scopo della Posizione: Amministra e gestisce l'azienda

## Responsabilita': 
-Collaborare con il Direttore per il raggiungimento degli obbiettivi generali e di profitto
-Gestire i sottoposti
-Gestire i contatti con le aziende esterne

## Compiti e mansioni:
-Sovrintendere i programmatori e gli addetti all'assistenza
-Relazionarsi con gli enti esterni in assenza del Direttore 
-Gestione dei beni dell'azienda
