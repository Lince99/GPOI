
## Posizione: Direttore

## Dipartimento: Direzione

## Dipendenza gerarchica:

### Dipendenza funzionale: Amministrazione generale, controllo sottoposti

##A lui riportano:Amministratore generale, programmatori software sicurezza, programmatori software m0n0wall, addetti all'assistenza

## Rapporti interfuzionali interni: tutti i dipartimenti

## Rapporti esterni: aziende "Netgear", "Sandisk" (fornitori), banca, servizi logistici (Magazzino, logistica), enti pubblici

## Scopo della Posizione: Amministra e gestisce l'azienda

## Responsabilita':
-Collaborare con l'amministratore generale per il raggiungimento degli obbiettivi generali e di profitto
-Mantenere il giusto clima all'interno dell'azienda
-Gestire i sottoposti
-Gestire i contatti con le aziende esterne

## Compiti e mansioni:
-Sovrintendere l'Amministratore generale
-Relazionarsi con gli enti esterni
-Gestione dei beni dell'azienda
