
## Posizione: Programmatore software sicurezza

## Dipartimento: Programmazione

## Dipendenza gerarchica: Direttore, Amministratore generale

### Dipendenza funzionale

## Rapporti interni: tutti

## Raporti esterni:

## Scopo della Posizione: Programmare e mantenere i software di sicurezza

## Responsabilita':
-Assicurarsi che il software sia affidabile e senza bug
-Non distribuire il software e/o infromazioni dell'azienda

## Compiti e mansioni:
-Risolvere gli eventuali bug pressenti nel software
-Sviluppare nuovi software
-Ottimizzare il software
