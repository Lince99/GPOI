
# Posizione: 
Programmatore software M0n0wall

## Dipartimento: 
Programmazione

### Dipendenza gerarchica: 
Direttore, Amministratore generale

### Dipendenza funzionale:
--

### Rapporti interni: 
tutti

### Raporti esterni:
--

## Scopo della Posizione: 
Programmare e mantenere il software "M0n0wall", assemblare e spedire il prodotto

## Responsabilita':
- Assicurarsi che il software sia affidabile e senza bug
- Non distribuire il software e/o infromazioni dell'azienda

## Compiti e mansioni:
- Risolvere gli eventuali bug pressenti nel software
- Sviluppare aggiornamenti del software
- Ottimizzare il software
- Assemblaggio router e imballaggio
