# SecuritySoft

## RUOLI

- (4) organigramma e gradi di specializzazione = Andoniu
- (1) BCM (Business Canvas Model) = Bernardi
- (3) Meccanismi di coordinamento = Andoniu
- (5) Mansionari = Andoniu
- (2) Prodotti e design = Dalzotto
- (6) Costi e BEP (Break Even Point) = Basso
- (7) Presentazione = tutti


## BCM

Partner chiave: Netgear fornisce hardware router, SanDisk per le chiavette

Attività chiave: software di sicurezza per l'ambiente domestico, domotico e piccole aziende. Produzione router con integrazione domotica

Risorse chiave: 1 ufficio con 3 stanze (commerciale, sviluppo, magazzino), 10 persone, commercialisti esterni, software nostro

Proposte di valore: azienda giovane molto competente di garanzia e sicurezza personale.

Relazioni con i Clienti: assistenza remota via mail, teamviewer e guida tramite FAQ

Canali: sito web, numero telefonico, pubblicità

Segmenti di clientela: Privati, piccole aziende nel settore tecnico/industriale


## PRODOTTI

- Software vari già sviluppati in precedenza
- Chiavetta con lettore impronte digitali
- Router con m0n0wall e software di gestione della casa

## COLLEGAMENTI CON ALTRE MATERIE

### Presentazione

- Titolo (tutti) (secs)
- BCM (Berna) (3 min)
- Prodotti (Dalzo) (1 min)
- Struttura (Andoniu) (1 min)
- Organigramma e specializzazioni (Andoniu) (2 min)
- Meccanismi di coordinamento e esempi (Basso) (3 min)
- Mansionari:
	- Direttore e Amministratore (Dalzo) (2 min)
	- Programmatore software e monowall (Berna) (2 min)
	- Assistenza (Basso) (1 min)
- Pagina finale (tutti) (secs)

### GPOI LAB

Foglio di Calcolo con BEP

### Licenza

Copyright (C) 2019 SecuritySoft (not so R)
Not a real one.
